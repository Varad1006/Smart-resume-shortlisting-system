# 🏗️ ARCHITECTURE DIAGRAM & FLOW CHARTS

## System Architecture Comparison

### BEFORE: Google Cloud Dependent
```
┌─────────────────────────────────────────────────────────────────┐
│                         BROWSER (React)                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │            Frontend Application (App.js)                 │  │
│  ├─────────────────────────────────────────────────────────┤  │
│  │  • Job Description Input                                 │  │
│  │  • Google Cloud Credentials (JSON) ← USER INPUT         │  │
│  │  • Resume File Upload                                    │  │
│  │  • GitHub Token (optional)                               │  │
│  │  • Process Button                                        │  │
│  │  • Results Display                                       │  │
│  └─────────────────────────────────────────────────────────┘  │
│                          ↓↑ (HTTP)                               │
├─────────────────────────────────────────────────────────────────┤
│                  INTERNET (Network Calls)                        │
├─────────────────────────────────────────────────────────────────┤
│              ↓ (Credentials)              ↓ (Credentials)        │
│  ┌──────────────────────────┐   ┌──────────────────────────┐  │
│  │  Google Vision API       │   │ Google Translate API     │  │
│  │  (OCR Service)           │   │ (Translation Service)    │  │
│  └──────────────────────────┘   └──────────────────────────┘  │
│         ↑ (Cost per call)               ↑ (Cost per call)       │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘

PROBLEMS: ❌ Credentials needed in frontend
          ❌ Sensitive data exposure
          ❌ API costs and rate limits
          ❌ Network dependency
          ❌ Complex setup
```

---

### AFTER: Open-Source & Local
```
┌─────────────────────────────────────────────────────────────────┐
│                         BROWSER (React)                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │            Frontend Application (App.js) ✨ SIMPLIFIED   │  │
│  ├─────────────────────────────────────────────────────────┤  │
│  │  • Job Description Input                                 │  │
│  │  • Resume File Upload                                    │  │
│  │  • GitHub Token (optional)                               │  │
│  │  • Process Button                                        │  │
│  │  • Results Display                                       │  │
│  └─────────────────────────────────────────────────────────┘  │
│                          ↓↑ (HTTP)                               │
├─────────────────────────────────────────────────────────────────┤
│                    FastAPI Backend                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │           Resume Processing Pipeline                     │  │
│  ├──────────────────────────────────────────────────────────┤  │
│  │                                                            │  │
│  │  1. PDF/Image Upload                                     │  │
│  │     ↓                                                     │  │
│  │  2. Extract Text (PyPDF2 or Tesseract) ✨ LOCAL         │  │
│  │     ↓                                                     │  │
│  │  3. Detect Language (langdetect) ✨ LOCAL               │  │
│  │     ↓                                                     │  │
│  │  4. Translate if needed (translate lib) ✨ FREE API     │  │
│  │     ↓                                                     │  │
│  │  5. Generate Embeddings (SentenceTransformer) ✨ LOCAL  │  │
│  │     ↓                                                     │  │
│  │  6. Rank Candidates (Cross-Encoder) ✨ LOCAL            │  │
│  │     ↓                                                     │  │
│  │  7. Fetch Social Stats (GitHub API) - Optional          │  │
│  │     ↓                                                     │  │
│  │  8. Store Results (MongoDB)                              │  │
│  │                                                            │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                   │
│  ✨ = Open-source or Local (No credentials needed)              │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘

BENEFITS: ✅ No credentials in frontend
          ✅ No sensitive data exposure
          ✅ No API costs
          ✅ Local processing (mostly offline)
          ✅ Simple setup
          ✅ Better privacy
```

---

## Data Flow Diagram

### Processing Flow
```
                    START: User Upload
                           │
                           ↓
                 ┌──────────────────┐
                 │   Job Desc       │
                 │   Resume Files   │
                 │   GitHub Token   │
                 └──────┬───────────┘
                        │
                        ↓
        ┌───────────────────────────────┐
        │  Extract Text from Each File  │
        ├───────────────────────────────┤
        │ IF PDF: Use PyPDF2            │
        │ IF Image: Use Tesseract ✨   │
        └───────────────┬───────────────┘
                        │
                        ↓
        ┌───────────────────────────────┐
        │  Detect & Translate Language  │
        ├───────────────────────────────┤
        │ Detect: langdetect ✨        │
        │ Translate: translate lib ✨  │
        └───────────────┬───────────────┘
                        │
                        ↓
        ┌───────────────────────────────┐
        │   Generate Embeddings         │
        ├───────────────────────────────┤
        │ Job Desc → Bi-Encoder ✨     │
        │ Resume Text → Bi-Encoder ✨  │
        │ Result: Vector Similarity     │
        └───────────────┬───────────────┘
                        │
                        ↓
        ┌───────────────────────────────┐
        │   Cross-Encoder Ranking       │
        ├───────────────────────────────┤
        │ Pair: (Job Desc, Resume)      │
        │ Model: ms-marco-MiniLM ✨    │
        │ Result: Relevance Score       │
        └───────────────┬───────────────┘
                        │
                        ↓
        ┌───────────────────────────────┐
        │   Calculate Social Score      │
        ├───────────────────────────────┤
        │ IF GitHub Token:              │
        │   Fetch repos, stars, etc.    │
        │ Optional: LeetCode, CodeChef   │
        └───────────────┬───────────────┘
                        │
                        ↓
        ┌───────────────────────────────┐
        │   Combine Scores              │
        ├───────────────────────────────┤
        │ Combined =                    │
        │   0.4×BiEncoder +             │
        │   0.4×CrossEncoder +          │
        │   0.2×SocialScore             │
        └───────────────┬───────────────┘
                        │
                        ↓
        ┌───────────────────────────────┐
        │   Rank & Store Results        │
        ├───────────────────────────────┤
        │ Sort by Combined Score        │
        │ Store in MongoDB              │
        │ Return Top 10 Candidates      │
        └───────────────┬───────────────┘
                        │
                        ↓
                    END: Display Results
```

---

## Technology Stack Diagram

### Backend Services
```
                    FastAPI Server
                    (Port 8000)
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
        ↓                  ↓                  ↓
    
    ┌─────────────┐  ┌──────────────┐  ┌──────────────┐
    │   OCR       │  │ Translation  │  │  Ranking     │
    │ ─────────── │  │ ──────────── │  │ ──────────── │
    │ Tesseract   │  │ translate    │  │ Bi-Encoder   │
    │ pytesseract │  │ langdetect   │  │ CrossEncoder │
    │ Pillow      │  │              │  │ SentenceTX   │
    │ PyPDF2      │  │ ✨ Local     │  │ ✨ Local     │
    │ ✨ Local    │  │ ✨ Free API  │  │              │
    └─────────────┘  └──────────────┘  └──────────────┘
           │                │                  │
           └────────────────┼──────────────────┘
                            │
                            ↓
                   ┌─────────────────┐
                   │    MongoDB      │
                   │  (Results DB)   │
                   └─────────────────┘
                            │
                   ┌────────┴────────┐
                   ↓                 ↓
            ┌────────────────┐  ┌──────────────┐
            │ GitHub API     │  │ Optional:    │
            │ (Social Stats) │  │ LeetCode,    │
            │                │  │ CodeChef     │
            └────────────────┘  └──────────────┘
```

---

## Dependency Comparison

### Before (Google Cloud)
```
requirements.txt (114 packages including)
├── google-cloud-vision ❌
├── google-cloud-translate ❌
├── google-api-core ❌
├── google-auth ❌
├── google-cloud-core ❌
├── googleapis-common-protos ❌
├── sentence-transformers ✅
├── torch ✅
├── transformers ✅
└── ... (other dependencies)
```

### After (Open-Source) ✨
```
requirements.txt (113 packages including)
├── pytesseract ✨ (NEW)
├── Pillow ✨ (NEW - image processing)
├── langdetect ✨ (NEW - language detection)
├── translate ✨ (NEW - translation)
├── textblob ✨ (NEW - NLP)
├── sentence-transformers ✅
├── torch ✅
├── transformers ✅
└── ... (other dependencies)

Changes:
  Removed: 6 packages (Google Cloud suite)
  Added: 5 packages (Open-source alternatives)
  Net: -1 package, but less external dependency
```

---

## API Endpoint Comparison

### Before vs After
```
┌─────────────────────────────────────────────────────────────┐
│ ENDPOINT: POST /api/process                                 │
├─────────────────────────────────────────────────────────────┤
│ BEFORE:                          AFTER:                      │
│ ├─ job_description (req)   ├─ job_description (req)         │
│ ├─ google_credentials (req) ├─ google_credentials (opt) ✨  │
│ ├─ github_token (opt)       ├─ github_token (opt)           │
│ └─ resume_files (req)       └─ resume_files (req)           │
│                                                              │
│ Credentials parameter is now OPTIONAL & IGNORED ✨          │
└─────────────────────────────────────────────────────────────┘
```

---

## User Experience Flow

### Before: Complex Setup
```
USER                          SYSTEM
  │                             │
  ├─ Create Google Cloud Project
  │                             │
  ├─ Create Service Account     │
  │                             │
  ├─ Download JSON Credentials  │
  │                             │
  ├─ Copy-paste into Frontend ◄─┤ Form asks for credentials
  │                             │
  └─► Submit Job & Resumes     ├─► Process with APIs
                               ├─► Returns Results
                               │
                      (Cost: $0.60 per 100 images)
```

### After: Simple Setup ✨
```
USER                          SYSTEM
  │                             │
  └─► Install Tesseract (one-time) ◄─ Auto-detected if possible
      │
      ├─► Enter Job Description
      │                         │
      ├─► Upload Resumes       ├─► Process locally
      │                         ├─► No credentials needed
      └─► View Results ◄────── ◄─► Returns Results
      
              (Cost: $0 - Free & Open-Source!)
```

---

## Performance Characteristics

### OCR Processing
```
GOOGLE VISION API          TESSERACT OCR
├─ Speed: 0.5-2 sec       ├─ Speed: 1-3 sec
├─ Latency: Network       ├─ Latency: Local (none)
├─ Accuracy: Excellent    ├─ Accuracy: Good
├─ Cost: $0.60/100 images ├─ Cost: $0 (Free)
├─ Requires: Credentials  ├─ Requires: Installation
└─ Best for: Production   └─ Best for: Cost & Privacy
```

### Translation Processing
```
GOOGLE TRANSLATE API       TRANSLATE LIBRARY
├─ Speed: 0.5-1 sec       ├─ Speed: 0.5-2 sec
├─ Latency: Network       ├─ Latency: Mostly network
├─ Languages: 100+        ├─ Languages: 100+
├─ Cost: $15/M requests   ├─ Cost: Free (rate limited)
├─ Requires: Credentials  ├─ Requires: Internet
└─ Unlimited: Quota       └─ Limited: Free tier
```

---

## Deployment Architecture

### Local Development
```
Machine A (Your Computer)
├─ Frontend (npm start)
│  └─ http://localhost:3000
│
├─ Backend (uvicorn)
│  └─ http://127.0.0.1:8000
│
├─ Tesseract (installed)
│  └─ C:\Program Files\Tesseract-OCR\
│
└─ MongoDB (Atlas)
   └─ Cloud: mongodb+srv://...
```

### Production Deployment (Example)
```
Cloud Provider (Azure/AWS/GCP)
│
├─ Compute Instance
│  ├─ Backend Container
│  │  ├─ FastAPI (uvicorn)
│  │  └─ Tesseract (installed in image)
│  │
│  └─ Frontend (Static)
│     └─ React Build (npm run build)
│
└─ MongoDB Atlas
   └─ Managed Database
```

---

## Module Dependency Graph

### Backend Modules
```
server.py
├─ FastAPI
│  └─ Uvicorn (ASGI)
│
├─ OCR Pipeline
│  ├─ pytesseract
│  │  └─ Tesseract (system)
│  └─ Pillow (PIL)
│
├─ Translation Pipeline
│  ├─ translate
│  └─ langdetect
│
├─ Ranking Pipeline
│  ├─ sentence-transformers
│  │  └─ torch
│  └─ transformers (HuggingFace)
│
├─ Data Access
│  ├─ motor (async MongoDB)
│  ├─ pymongo
│  └─ pydantic (validation)
│
└─ External APIs
   └─ aiohttp (async HTTP)
      ├─ GitHub API
      ├─ LeetCode GraphQL
      └─ CodeChef API
```

### Frontend Modules
```
App.js (React 19)
├─ UI Components
│  └─ shadcn/ui library
│     └─ Tailwind CSS
│
├─ HTTP Client
│  └─ axios
│
├─ Notifications
│  └─ sonner (toast)
│
└─ Icons
   └─ lucide-react
```

---

## Summary: Before vs After

```
┌────────────────────────────────────────────────────────────────┐
│                      COMPARISON MATRIX                          │
├─────────────────────┬──────────────────┬──────────────────────┤
│ Aspect              │ BEFORE           │ AFTER ✨             │
├─────────────────────┼──────────────────┼──────────────────────┤
│ OCR                 │ Google Vision    │ Tesseract (Free)     │
│ Translation         │ Google Translate │ translate (Free)     │
│ Cost                │ $0.60 per 100    │ $0 (Free)            │
│ Credentials         │ Required         │ None ✨              │
│ Frontend Form       │ Complex          │ Simple ✨            │
│ Setup Time          │ 15-30 min        │ 5-10 min ✨          │
│ Privacy             │ Data to Google   │ Local Processing ✨  │
│ Offline Support     │ No               │ Yes (mostly) ✨      │
│ Quota Limits        │ Yes              │ No ✨                │
│ Dependencies        │ 114 packages     │ 113 packages ✨      │
│ External APIs       │ 2 (required)     │ 0 (all optional) ✨  │
└─────────────────────┴──────────────────┴──────────────────────┘
```

---

**Visual Reference Complete** ✨
Ready for deployment!
